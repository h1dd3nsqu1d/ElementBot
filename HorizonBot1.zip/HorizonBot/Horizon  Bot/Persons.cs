﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Horizon__Bot
{
    public class Resume
    {
        

        public string F3_1 = "ФИО Кандидата: ";
        public string F3_2 = "Номер телефона: ";
        public string F3_3 = "Возраст: ";
        public string F3_4 = "Город проживания: ";
        public string F3_5 = "Стаж по правам: ";
        public string F3_6 = "Стаж в такси: ";
        public string F3_7 = "Есть ли аккаунт UBER: ";
        public string F3_8 = "Судимости: ";
        public string F3_9 = "ДТП: ";
        public string F3_11 = "Ваш агент: ";
        public string F3_12 = "Время и дата собеседования: ";
        public string F3_13 = "Ваше Имя и Фамилия: ";
        public string F3_14 = "Партнер, к которому записан кандидат: ";

        public string[] F = new string[14];

        public string F2_1;
        public string F2_2;
        public string F2_3;
        public string F2_4;
        public string F2_5;
        public string F2_6;
        public string F2_7;
        public string F2_8;
        public string F2_9;
        public string F2_11;
        public string F2_12;
        public string F2_13;
        public string F2_14;

        public string[] Make_Array(out string[] empt ) {
            empt = new string[14];
            empt[0]= F2_13;
            empt[1]= F2_1;
            empt[2]= F2_2;
            empt[3]= F2_3;
            empt[4]= F2_4;
            empt[5]= F2_5;
            empt[6]= F2_6;
            empt[7]= F2_7;
            empt[8]= F2_8;
            empt[9]= F2_9;
            empt[10]= F2_11;
            empt[11]= F2_12;
            empt[12]= F2_14;

            return empt;
        }

        public string Make_Resume()
        {
            string CV;

            CV = "\nАнкета:\n" + F3_1 + F2_1 + "\n" + F3_2 + F2_2 + "\n" + F3_3 + F2_3 + "\n" + F3_4 + F2_4 + "\n" + F3_5 + F2_5 + "\n" + F3_6 + F2_6 + "\n" + F3_7 + F2_7 + "\n" +
               F3_8+ F2_8 + "\n" + F3_9 + F2_9 + "\n" + F3_11 + F2_11 + "\n" + F3_12 + F2_12 + "\n" + F3_13 + F2_13 + "\n" + F3_14 + F2_14 + "\n";
            return CV;
        }
    }

    class Post
    {
        public Stack<double> Codes = new Stack<double>();

        public long Chat_ID;

        public Resume Resume = new Resume();

    }
}
