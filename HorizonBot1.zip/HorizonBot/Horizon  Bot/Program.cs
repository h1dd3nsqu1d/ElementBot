﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Types.ReplyMarkups;
using Telegram.Bot.Types.Enums;
using System.IO;

namespace Horizon__Bot
{  
    class HrBot
    {
        private static List<Post> Persons = new List<Post>();
        public static string TOKEN = "";
        private static readonly TelegramBotClient Bot = new TelegramBotClient(TOKEN);
        private static readonly long Channel_ID =;

        private static string Logs="logs.dat";

        private static string fullNameFiller = "";

        static void Main( )
        {
            
           
            while (true)
            {
                try
                {
                    GetMessages().Wait();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                    Console.WriteLine("Exception30");
                }
            }
        }
        static async Task GetMessages()
        {
            TelegramBotClient bot = new TelegramBotClient(TOKEN);
            int offset = 0;
            int timeout = 0;

            try
            {
                await bot.SetWebhookAsync("");

                while (true)
                {
                    var updates = await bot.GetUpdatesAsync(offset, timeout);

                    foreach (var update in updates)
                    {
                        var message = update.Message;

                        if (update.Message != null)
                        {

                            try
                            {
                                await Bot_OnMessage(bot, update);
                            }
                            catch (Exception) {
                                Console.WriteLine("Error");
                                Console.WriteLine("Exception60");
                                Main();
                            }

                        }
                        offset = update.Id + 1;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex);
                Console.WriteLine("Exception71");
            }
        }

        public static async Task Bot_OnMessage(object sender, Telegram.Bot.Types.Update e)
        {         
            Post Code=new Post();

            if (Is_Init(Persons, e.Message.Chat.Id))
            {               
                    Code = Return_Chat(Persons, e.Message.Chat.Id); // Returning chat from  list                
            }
            else
            {
                Code = new Post();
                Code.Chat_ID = e.Message.Chat.Id;
                Persons.Add(Code);
            }

            Txt_check(e.Message.Text, Code); // Messages  parser
           
          
            try
            {
                await Bot_Messages(e, sender, Code); //Response
            }
            catch (Exception ex) {

                await Bot_OnMessage(sender, e);
                Console.WriteLine("Exception98");
            }
            double[] arr1 = new double[Code.Codes.Count];
            arr1 = Code.Codes.ToArray();
            Console.Write("\n Command stack: ");
            foreach (double a in arr1)
            {
                Console.Write(a + " ");
            }
        }

        public static bool Is_Init(List<Post> Persons, long Chat_Id)
        {
            foreach (Post el in Persons)
            {
                if (el.Chat_ID == Chat_Id)
                {
                    return true;
                }
            }
            return false;
        }

        public static Post Return_Chat(List<Post> Persons, long Chat_Id)
        {
            foreach (Post el in Persons)
            {
                if (el.Chat_ID == Chat_Id)
                {
                    return el;
                }
            }
            return null;
        }

        public static void Txt_check(string Message, Post el)
        {
            const int Code_Yes = 11;
            const int Code_No = 10;
            const int Retry = 20;
            const int Edit = 21;
            const int Finish = 99;
            const int Instruction = 13;
            const int About = 14;
            const int Manager = 19;
            const int Conditions = 15;
            const int Strategies = 16;
            const int Script = 17;
            const int Vacancies = 45;
            const int Contacts = 46;
            const int Site = 47;
            const int News = 48;
            const int Salary = 49;
            const int FillerName = 56;
            




            const int Code_Send = 200;  //send 200 - 200

            const int Name = 31;
            const int Number = 32;
            const int Age = 33;
            const int City = 34;
            const int Stag = 35;
            const int Taxi = 36;
            const int Uber = 37;
            const int Jail = 38;
            const int DTP = 39;
            const int Agent = 40;
            const int Date = 41;
            const int Filler = 42;
            const int Partner = 43;

            switch (Message)
            {
                case ("1)ФИО Кандидата"):
                    {
                        el.Codes.Push(Name);
                    }
                    break;
                case ("2)Номер телефона"):
                    {
                        el.Codes.Push(Number);
                    }
                    break;
                case ("3)Возраст"):
                    {
                        el.Codes.Push(Age);

                    }
                    break;
                case ("4)Город проживания"):
                    {
                        el.Codes.Push(City);
                    }
                    break;
                case ("5)Стаж по правам"):
                    {
                        el.Codes.Push(Stag);
                    }
                    break;
                case ("6)Стаж в такси"):
                    {
                        el.Codes.Push(Taxi);
                    }
                    break;
                case ("7)Есть ли аккаунт UBER"):
                    {
                        el.Codes.Push(Uber);
                    }
                    break;
                case ("8)Судимости"):
                    {
                        el.Codes.Push(Jail);
                    }
                    break;
                case ("9)ДТП"):
                    {
                        el.Codes.Push(DTP);
                    }
                    break;
                case ("10)Ваш агент"):
                    {
                        el.Codes.Push(Agent);
                    }
                    break;
                case ("11)Время и дата собеседования"):
                    {
                        el.Codes.Push(Date);
                    }
                    break;
                case ("12)Ваше Имя и Фамилия"):
                    {
                        el.Codes.Push(Filler);
                    }
                    break;
                case ("13)Партнер"):
                    {
                        el.Codes.Push(Partner);
                    }
                    break;
                case ("да"):
                    {
                        el.Codes.Push(Code_Yes);
                    }
                    break;

                case ("Да"):
                    {
                        el.Codes.Push(Code_Yes);
                    }
                    break;
                case ("Заполнить анкету"):
                    {
                        el.Codes.Push(Code_Yes);
                    }
                    break;
                case ("Меню"):
                    {
                        el.Codes.Push(Instruction);
                    }
                    break;
                case ("Вакансии"):
                    {
                        el.Codes.Push(Vacancies);
                       
                    }
                    break;
                case ("Знакомство"):
                    {
                        el.Codes.Push(About);
                    }
                    break;
                case ("Фрилансер"):
                    {
                        el.Codes.Push(Conditions);
                        
                    }
                    break;
                case ("Менеджер"):
                    {
                        el.Codes.Push(Manager);

                    }
                    break;
                case ("Стратегии"):
                    {
                        el.Codes.Push(Strategies);
                    }
                    break;
                case ("Скрипт"):
                    {
                        el.Codes.Push(Script);
                    }
                    break;
                case ("Контакты"):
                    {
                        el.Codes.Push(Contacts);
                    }
                    break;
                case ("Сайт"):
                    {
                        el.Codes.Push(Site);
                    }
                    break;
                case ("Новости"):
                    {
                        el.Codes.Push(News);
                    }
                    break;
                case ("Зарплата"):
                    {
                        el.Codes.Push(Salary);
                    }
                    break;
                case ("Ввести ФИО"):
                    {
                        el.Codes.Push(FillerName);
                    }
                    break;
                case ("Отправить анкету"):
                    {
                        el.Codes.Push(Code_Send);
                        el.Codes.Push(Code_Send);
                    }
                    break;
                case ("Подтверждение"):
                    {
                        el.Codes.Push(Code_Yes);
                    }
                    break;
                case ("Продолжить"):
                    {
                        el.Codes.Push(Code_Yes);
                    }
                    break;

                case ("Откорректировать"):
                    {
                        Console.WriteLine("EDIT");
                        el.Codes.Push(Edit);
                    }
                    break;

                case ("Перезапустить заполнение"):
                    {
                        el.Codes.Push(Retry);
                    }
                    break;

                case ("No"):
                    el.Codes.Push(Code_No);
                    break;

                case ("Не оставлять анкету"):
                    el.Codes.Push(Finish);
                    break;
                case ("Вернуться назад"):
                    el.Codes.Push(Finish);
                    break;
                case ("/finish"):
                    el.Codes.Push(Finish);
                    break;
                default:
                    el.Codes.Push(100);
                    break;
            }
        }

        public static async Task Bot_Messages(Telegram.Bot.Types.Update e, object sender, Post el)
        {
            const string Init = "Привет!\nЯ - официальный бот компании Element.";

            string Instructions = "Введите  свою  информацию согласно форме:"
             + el.Resume.Make_Resume();
            const string I2_1 = "ФИО Кандидата: ";
            const string I2_2 = "Номер телефона: ";
            const string I2_3 = "Возраст: ";
            const string I2_4 = "Город проживания: ";
            const string I2_5 = "Стаж по правам: ";
            const string I2_6 = "Стаж в такси: ";
            const string I2_7 = "Есть ли аккаунт UBER: ";
            const string I2_8 = "Судимости: ";
            const string I2_9 = "ДТП: ";
            const string I2_11 = "Ваш агент: ";
            const string I2_12 = "Время и дата собеседования: ";
            const string I2_13 = "Ваше имя и фамилия: ";
            const string I2_14 = "Партнер, к которому записан кандидат: ";
            const string Confirmation = "Продолжить?";  // Не участвует  в  логе  
            const string Code_Bye = "Спасибо, Ваша анкета принята";
            const string Instruction = "Выберите интересующий Вас пункт: ";



            if (el.Codes.Count > 1)
            {

                bool Txt_Chk = el.Codes.Peek() == 11 || el.Codes.Peek() == 100 || el.Codes.Peek() == 10 || el.Codes.Peek() == 13;
                bool edit = (el.Codes.ElementAt(1) == 31 || el.Codes.ElementAt(1) == 32 || el.Codes.ElementAt(1) == 33 || el.Codes.ElementAt(1) == 34 || el.Codes.ElementAt(1) == 35 || el.Codes.ElementAt(1) == 36 || el.Codes.ElementAt(1) == 37 || el.Codes.ElementAt(1) == 38 || el.Codes.ElementAt(1) == 39 || el.Codes.ElementAt(1) == 40 || el.Codes.ElementAt(1) == 41 || el.Codes.ElementAt(1) == 42 || el.Codes.ElementAt(1) == 43 || el.Codes.ElementAt(1) == 56 || el.Codes.ElementAt(1) == 49);

                if (el.Codes.Peek() == 11 && (el.Codes.ElementAt(1) == 0))
                {
                    var kbq = new ReplyKeyboardMarkup
                    {
                        Keyboard = new[]  {
                            new[]{
                                new KeyboardButton("Меню"),

                            },
                            new[]
                            {
                                new KeyboardButton("Вакансии"),
                                new KeyboardButton("Заполнить анкету"),
                            },


                        },
                        ResizeKeyboard = true
                    };
                    try
                    {
                        el.Codes.Push(1);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, Init, ParseMode.Html, false, false, 0, kbq);
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception375");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }



               /* else if (el.Codes.Peek() == 42)
                {
                    el.Codes.Pop();
                    el.Codes.Push(0);
                    el.Codes.Push(11);
                    fullNameFiller = e.Message.Text;
                    GoogleSheets.AddToSalaryTable(fullNameFiller);
                }*/

                /*else if (el.Codes.Peek() == 11 && el.Codes.ElementAt(1) == 42)
                {
                }*/

                else if (el.Codes.Peek() == 13)
                {


                    var kbd = new ReplyKeyboardMarkup
                    {
                        Keyboard = new[] {
                            new[] {
                                new KeyboardButton("Вернуться назад")
                            },
                            new[]
                            {
                                new KeyboardButton("Знакомство"),
                                new KeyboardButton("Фрилансер"),
                                new KeyboardButton("Менеджер"),

                            },
                            new[]
                            {
                                new KeyboardButton("Стратегии"),
                                new KeyboardButton("Скрипт"),
                                new KeyboardButton("Контакты"),

                            },
                            new[]
                             {
                                new KeyboardButton("Сайт"),
                                new KeyboardButton("Новости"),
                                new KeyboardButton("Зарплата"),
                                new KeyboardButton("Ввести ФИО"),
                             }
                        },
                        ResizeKeyboard = true
                    };


                    try
                    {
                        el.Codes.Push(1);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, Instruction, ParseMode.Html, false, false, 0, kbd);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 11 && (el.Codes.ElementAt(1) == 1) || (el.Codes.Peek() == 11 && (el.Codes.ElementAt(1) == 13) || (el.Codes.Peek() == 11 && (el.Codes.ElementAt(1) == 45))))
                {
                    var kbd = new ReplyKeyboardMarkup
                    {
                        Keyboard = new[] {
                            new[]{
                                new KeyboardButton("Продолжить")
                            },
                            new[]{
                                 new KeyboardButton("Не оставлять анкету")
                            }
                        },
                        ResizeKeyboard = true
                    };
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, Instructions);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, Confirmation, ParseMode.Html, false, false, 0, kbd);
                        el.Codes.Push(2);
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception435");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 11 && (el.Codes.ElementAt(1) == 2))
                {
                    try
                    {
                        el.Codes.Push(2.1);
                        ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_1, ParseMode.Default, false, false, 0, keyboardRemove);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 100 && (el.Codes.ElementAt(1) == 2.1))
                {
                    try
                    {
                        el.Resume.F2_1 = e.Message.Text;
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_2);
                        el.Codes.Push(2.2);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.2))
                {
                    try
                    {
                        el.Resume.F2_2 = e.Message.Text;
                        el.Codes.Push(2.3);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_3);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 100 && (el.Codes.ElementAt(1) == 2.3))
                {
                    try
                    {
                        el.Resume.F2_3 = e.Message.Text;
                        el.Codes.Push(2.4);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_4);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 100 && (el.Codes.ElementAt(1) == 2.4))
                {
                    try
                    {
                        el.Resume.F2_4 = e.Message.Text;
                        el.Codes.Push(2.5);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_5);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.5))
                {
                    try
                    {
                        el.Resume.F2_5 = e.Message.Text;
                        el.Codes.Push(2.6);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_6);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.6))
                {
                    try
                    {
                        el.Resume.F2_6 = e.Message.Text;
                        el.Codes.Push(2.7);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_7);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.7))
                {
                    try
                    {
                        el.Resume.F2_7 = e.Message.Text;
                        el.Codes.Push(2.8);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_8);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.8))
                {
                    try
                    {
                        el.Resume.F2_8 = e.Message.Text;
                        el.Codes.Push(2.9);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_9);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.9))
                {
                    try
                    {
                        el.Resume.F2_9 = e.Message.Text;
                        el.Codes.Push(2.11);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_11);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.11))
                {
                    try
                    {
                        el.Resume.F2_11 = e.Message.Text;
                        el.Codes.Push(2.12);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_12);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.12))
                {
                    try
                    {
                        el.Resume.F2_12 = e.Message.Text;
                        el.Codes.Push(2.13);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_13);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.13))
                {
                    try
                    {
                        el.Resume.F2_13 = e.Message.Text;
                        el.Codes.Push(2.14);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, I2_14);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (Txt_Chk && (el.Codes.ElementAt(1) == 2.14))
                {
                    try
                    {
                        el.Resume.F2_14 = e.Message.Text;
                        el.Codes.Push(3);
                        el.Codes.Push(3);
                        await Bot_Messages(e, sender, el);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }


                else if (el.Codes.Peek() == 100 && el.Codes.ElementAt(1) == 56)
                {
                    fullNameFiller = e.Message.Text;
                    var chatId = e.Message.Chat.Id;
                    GoogleSheets.AddToSalaryTable(fullNameFiller, chatId);
                    el.Codes.Clear();
                    el.Resume = new Resume();
                    await Bot_Messages(e, sender, el);

                }
                else if ((el.Codes.Peek() == 3 && (el.Codes.ElementAt(1) == 3)) || (Txt_Chk && edit))
                {
                    if (Txt_Chk && edit)
                    {
                        switch (el.Codes.ElementAt(1))
                        {
                            case 31:
                                el.Resume.F2_1 = e.Message.Text;
                                break;
                            case 32:
                                el.Resume.F2_2 = e.Message.Text;
                                break;
                            case 33:
                                el.Resume.F2_3 = e.Message.Text;
                                break;
                            case 34:
                                el.Resume.F2_4 = e.Message.Text;
                                break;
                            case 35:
                                el.Resume.F2_5 = e.Message.Text;
                                break;
                            case 36:
                                el.Resume.F2_6 = e.Message.Text;
                                break;
                            case 37:
                                el.Resume.F2_7 = e.Message.Text;
                                break;
                            case 38:
                                el.Resume.F2_8 = e.Message.Text;
                                break;
                            case 39:
                                el.Resume.F2_9 = e.Message.Text;
                                break;
                            case 40:
                                el.Resume.F2_11 = e.Message.Text;
                                break;
                            case 41:
                                el.Resume.F2_12 = e.Message.Text;
                                break;
                            case 42:
                                el.Resume.F2_13 = e.Message.Text;
                                break;
                            case 43:
                                el.Resume.F2_14 = e.Message.Text;
                                break;
                        }
                    }
                    var kbd = new ReplyKeyboardMarkup

                    {
                        Keyboard = new[] {
                            new[]{
                                new KeyboardButton("Отправить анкету"),
                                new KeyboardButton("Откорректировать")

                            },
                            new[]{
                                 new KeyboardButton("Не оставлять анкету"),
                                 new KeyboardButton("Перезапустить заполнение")
                            }
                        },
                        ResizeKeyboard = true
                    };
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, el.Resume.Make_Resume());
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, Confirmation, ParseMode.Html, false, false, 0, kbd);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el); Console.WriteLine("Exception1");
                    }
                }

                else if (el.Codes.Peek() == 200 && (el.Codes.ElementAt(1) == 200))
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();

                    string CV = el.Resume.Make_Resume();
                    string[] sheets_CV;
                    try
                    {
                        await Bot.SendTextMessageAsync(Channel_ID, CV); //Sending
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, Code_Bye, ParseMode.Html, false, false, 0, keyboardRemove);
                        el.Resume.Make_Array(out sheets_CV);
                        GoogleSheets sheet = new GoogleSheets();

                        await sheet.Send_CV(sheets_CV);

                        Console.WriteLine("Sended Resume!");
                        Console.WriteLine("\nRESUME:\n" + CV);

                        //FileStream file = new FileStream(Logs, FileMode.OpenOrCreate);



                        el.Codes.Clear();
                        el.Resume = new Resume();
                    }
                    catch (Exception)
                    {
                        try { await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Ошибка!\n Не удалось  отправить  анкету ", ParseMode.Html, false, false, 0, keyboardRemove); }
                        catch (Exception) { Console.WriteLine("Exception728"); }
                    }

                    el.Codes.Push(99);
                    await Bot_Messages(e, sender, el);
                }
                else if (el.Codes.Peek() == 21)// 300 is edited  markup
                {
                    var kbd = new ReplyKeyboardMarkup
                    {
                        Keyboard = new[] {
                            new[]{
                                new KeyboardButton("1)ФИО Кандидата"),
                                new KeyboardButton("2)Номер телефона"),
                                new KeyboardButton("3)Возраст")
                            },
                            new[]{

                                 new KeyboardButton("4)Город проживания"),
                                 new KeyboardButton("5)Стаж по правам"),
                                 new KeyboardButton("6)Стаж в такси")
                            },
                            new[]{
                                 new KeyboardButton("7)Есть ли аккаунт UBER"),
                                 new KeyboardButton("8)Судимости"),
                                 new KeyboardButton("9)ДТП")
                            },
                             new[]{
                                 new KeyboardButton("10)Ваш агент"),
                                 new KeyboardButton("11)Время и дата собеседования"),
                                 new KeyboardButton("12)Ваше Имя и Фамилия"),
                            },
                             new[]{
                                 new KeyboardButton("13)Партнер")
                            }
                        },
                        ResizeKeyboard = true
                    };
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Выберите что отредактировать", ParseMode.Html, false, false, 0, kbd);
                    }
                    catch (Exception)
                    {
                        el.Codes.Push(99);
                        Console.WriteLine("Exception772");
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 31)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старое " + el.Resume.F2_1, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новое ФИО:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception786");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 32)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старый " + el.Resume.F2_2, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый номер телефона:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception800");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 33)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старый " + el.Resume.F2_3, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый Возраст:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception814");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 34)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старый " + el.Resume.F2_4, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый Город проживания:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception828");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 35)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старый " + el.Resume.F2_5, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый Стаж по правам:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception842");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 36)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старый " + el.Resume.F2_6, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый Стаж в такси:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception856");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 37)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, el.Resume.F2_7, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый статус: ");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception870");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 38)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, el.Resume.F2_8, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый статус: ");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception884");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 39)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, el.Resume.F2_9, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новый статус: ");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception898");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 40)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старая информация: " + el.Resume.F2_11, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите Вашего агента: ");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception912");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 41)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старая: " + el.Resume.F2_12, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новую дату:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception927");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 42)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старая информация: " + el.Resume.F2_13, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите новую: ");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception940");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 43)
                {
                    ReplyKeyboardRemove keyboardRemove = new ReplyKeyboardRemove();
                    try
                    {
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Старый " + el.Resume.F2_14, ParseMode.Html, false, false, 0, keyboardRemove);
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите нового партнера:");
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception955");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }

                else if (el.Codes.Peek() == 20)
                {
                    try
                    {
                        el.Codes.Push(1);
                        el.Codes.Push(11);
                        el.Resume = new Resume();
                        await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Перезапуск...");
                        await Bot_Messages(e, sender, el);
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception972");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else if (el.Codes.Peek() == 14) // add  exceptions  here
                {
                    el.Codes.Push(14);

                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.About, ParseMode.Html, false, false, 0);

                }
                else if (el.Codes.Peek() == 19)
                {
                    el.Codes.Push(19);

                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Manager, ParseMode.Html, false, false, 0);
                }

                else if (el.Codes.Peek() == 15)
                {

                    el.Codes.Push(15);


                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Conditions, ParseMode.Html, false, false, 0);

                }


                else if (el.Codes.Peek() == 16)
                {
                    el.Codes.Push(16);
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Strategies, ParseMode.Html, false, false, 0);

                }
                else if (el.Codes.Peek() == 17)
                {
                    el.Codes.Push(17);
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Script, ParseMode.Html, false, false, 0);

                }
                else if (el.Codes.Peek() == 46)
                {
                    el.Codes.Push(46);

                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Contacts, ParseMode.Html);
                }
                else if (el.Codes.Peek() == 48)
                {
                    el.Codes.Push(48);

                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.News, ParseMode.Html);
                }
                else if(el.Codes.Peek() == 56)
                {
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Введите ваше Имя и Фамилию", ParseMode.Html, false, false, 0);

                }

                else if (el.Codes.Peek() == 49)
                {
                    el.Codes.Push(49);
                    var chatId = e.Message.Chat.Id;
                    string salary = GoogleSheets.GetSalary(chatId);
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, salary , ParseMode.Html);
                }
                else if (el.Codes.Peek() == 47)
                {
                    el.Codes.Push(47);

                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Site, ParseMode.Html);
                }
                else if (el.Codes.Peek() == 45)
                {
                    el.Codes.Push(45);

                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Vacancies, ParseMode.Html);
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Vacancies2, ParseMode.Html);
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, Texts.Vacancies3, ParseMode.Html);

                }




                //to  here

                else if (el.Codes.Peek() == 99) // clearing  commands  
                {
                    el.Codes.Clear();
                    el.Resume = new Resume();
                    await Bot_Messages(e, sender, el);

                }

                else if (el.Codes.Peek() == 13)
                {
                    try { await Bot.SendTextMessageAsync(e.Message.Chat.Id, Instruction, ParseMode.Html, false, false, 0); }
                    catch (Exception)
                    {
                        Console.WriteLine("Exception1027");
                        el.Codes.Push(99);
                        await Bot_Messages(e, sender, el);
                    }
                }
                else
                {
                    Console.WriteLine("Exception main");
                    el.Codes.Pop();
                    el.Codes.Pop();
                    await Bot_Messages(e, sender, el);
                }
            }

            else if (el.Codes.Count() == 0 || el.Codes.Peek() == 0)
            {
                el.Codes.Push(0);
                el.Codes.Push(11);
                await Bot_Messages(e, sender, el);
            }
            else if (el.Codes.Peek() != 0)
            {
                el.Codes.Pop();
                el.Codes.Push(0);
                el.Codes.Push(11);
                await Bot_Messages(e, sender, el);

            }
            else
            {
                try
                {
                    await Bot.SendTextMessageAsync(e.Message.Chat.Id, "Привет");
                }
                catch (Exception)
                {
                    Console.WriteLine("Exception1063");
                    el.Codes.Push(99);
                    await Bot_Messages(e, sender, el);
                }
            }
        }
    }
}
