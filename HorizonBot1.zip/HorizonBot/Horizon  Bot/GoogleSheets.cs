﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Util.Store;

namespace Horizon__Bot
{
    class GoogleSheets
    {
        private static string ClientSecret = "client_secret.json";
        private static readonly string[] ScopesSheets = { SheetsService.Scope.Spreadsheets };
        private static readonly string AppName = "Sheetsloger";
        private static readonly string SpreadsheetId = "";
        private const string Range = "Зарплата!A1:A";
        private static int Last_Cell = 1; 

        private static string[,] Data = new string[,]
        {

                {"11", "12", "13", "14" },
                {"21", "22", "23", "24" },
                {"31", "32", "33", "34" },
        };

       public async Task Send_CV( string[] Person_Data )
        {        
            var credential = GetSheetCredentials();
            Console.WriteLine("Get Credentials\n");

            var service = GetService(credential);
            Console.WriteLine("Get Service\n");
            //Console.WriteLine("Fill data");
            //FillSpreadsheet(service, SpreadsheetId, Data);
            ////Console.WriteLine("Getting result");
            ////string result = GetFirstCell(service, Range, SpreadsheetId);
            ////Console.WriteLine("result: {0}", result);
            Last_Cell = GetLength(service, Range, SpreadsheetId);
            Console.WriteLine("GetLength\n");
            Fill_Next_Row(service, SpreadsheetId, Person_Data, Last_Cell);
            Console.WriteLine("Sent CV to spreadsheet\n");          
        }

        private static UserCredential GetSheetCredentials()
        {
            using (var stream = new FileStream(ClientSecret, FileMode.Open, FileAccess.Read))
            {
                var credPath = Path.Combine(Directory.GetCurrentDirectory(), "sheetsCreds.json");

                return GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    ScopesSheets,
                    "user",
                    CancellationToken.None,
                    new FileDataStore(credPath, true)).Result;
            }
        }

        private static SheetsService GetService(UserCredential credential)
        {
            return new SheetsService(new BaseClientService.Initializer
            {
                HttpClientInitializer = credential,
                ApplicationName = AppName
            });
        }

        private static void FillSpreadsheet(SheetsService service, string spreadsheetId, string[,] data)
        {
            List<Request> requests = new List<Request>();

            for (int i = 0; i < data.GetLength(0); i++)
            {
                List<CellData> values = new List<CellData>();

                for (int j = 0; j < data.GetLength(1); j++)
                {
                    values.Add(new CellData
                    {
                        UserEnteredValue = new ExtendedValue
                        {
                            StringValue = data[i, j]
                        }
                    });
                }
                requests.Add(
                    new Request
                    {
                        UpdateCells = new UpdateCellsRequest
                        {
                            Start = new GridCoordinate
                            {
                                SheetId = 0,
                                RowIndex = i,
                                ColumnIndex = 0
                            },
                            Rows = new List<RowData> { new RowData { Values = values } },
                            Fields = "userEnteredValue"
                        }
                    }
            );
            }
            BatchUpdateSpreadsheetRequest busr = new BatchUpdateSpreadsheetRequest
            {
                Requests = requests
            };
            service.Spreadsheets.BatchUpdate(busr, spreadsheetId).Execute();
        }

        private static void Fill_Next_Row(SheetsService service, string spreadsheetId, string[] data, int position)
        {
            List<Request> requests = new List<Request>();

            
                List<CellData> values = new List<CellData>();

                for (int i = 0; i < data.Length; i++)
                {
                    values.Add(new CellData
                    {
                        UserEnteredValue = new ExtendedValue
                        {
                            StringValue = data[i]
                        }
                    });
                }
                requests.Add(
                    new Request
                    {
                        UpdateCells = new UpdateCellsRequest
                        {
                            Start = new GridCoordinate
                            {
                                SheetId = 0,
                                RowIndex = position,
                                ColumnIndex = 0
                            },
                            Rows = new List<RowData> { new RowData { Values = values } },
                            Fields = "userEnteredValue"
                        }
                    }
            );
            BatchUpdateSpreadsheetRequest busr = new BatchUpdateSpreadsheetRequest
            {
                Requests = requests
            };
            service.Spreadsheets.BatchUpdate(busr, spreadsheetId).Execute();
        }

        private static string GetFirstCell(SheetsService service, string range, string spreadsheetId)
        {
            SpreadsheetsResource.ValuesResource.GetRequest request = service.Spreadsheets.Values.Get(spreadsheetId, range);
            ValueRange response = request.Execute();

            string result = null;

            foreach (var value in response.Values)
            {
                result += " " + value[0];
            }
            return result;
        }

        private static int GetLength(SheetsService service, string range, string spreadsheetId)
        {
            SpreadsheetsResource.ValuesResource.GetRequest request = service.Spreadsheets.Values.Get(spreadsheetId, range);
            ValueRange response = request.Execute();

            int row_count=0;

            foreach (var value in response.Values)
            {
                    row_count++;
            }
            return row_count;
        }

        public static void AddToSalaryTable(string fullName, long chatId)
        {
            string range = "Зарплата!A2:B2";
            var service = GetService(GetSheetCredentials());
            var data = new List<object>();
            data.Add(chatId);
            data.Add(fullName);
            data.Add(0);
            var row = new List<IList<object>>();
            row.Add(data);
            ValueRange newData = new ValueRange()
            {
                Range = range,
                Values = row as IList<IList<object>>
            };
            SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum valueInputOption = (SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum)1;
            SpreadsheetsResource.ValuesResource.AppendRequest request = service.Spreadsheets.Values.Append(newData, SpreadsheetId, range);
            request.ValueInputOption = valueInputOption;
            AppendValuesResponse response = request.Execute();
        }

        public static string GetSalary(long chatId)
        {
            string range = "Зарплата!A2:A";
            var service = GetService(GetSheetCredentials());
            SpreadsheetsResource.ValuesResource.GetRequest request = service.Spreadsheets.Values.Get(SpreadsheetId, range);
            ValueRange response = request.Execute();
            int index = -1;
            foreach (var value in response.Values)
            {
                if (value.Contains(chatId.ToString()))
                {
                    index = response.Values.IndexOf(value);
                }
            }

            range = "Зарплата!C2:C";
            request = service.Spreadsheets.Values.Get(SpreadsheetId, range);
            response = request.Execute();

            return response.Values[index][0].ToString();
        }
    }
}
